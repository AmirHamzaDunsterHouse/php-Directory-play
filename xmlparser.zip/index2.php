<?php


    $files = array();

    //cource path $dir
    $dir = "./wad";

    // Open a directory, and read its contents
    if (is_dir($dir)){

        if ($dh = opendir($dir)){

            while (($file = readdir($dh)) !== false){

                //putting logic to ignore hidden files
                 if($file==='.' || $file==='..'){
                    continue;
                }
                //PUTTING LOGIC TO IGNORE RESPONSE FILES
                if (strpos($file, 'response') !== false)
                {
                continue;
                }
                
                rename("wad/".$file, "wad_no_res_files/".$file);


            }

            closedir($dh);
        }
    }


?>