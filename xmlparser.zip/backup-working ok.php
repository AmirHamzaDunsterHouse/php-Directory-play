<?php

 //declearing wanted files array
    $move_file_names = array();
    $Modified_file_dates=  array();
    $file_create_dates =  array();
    $files = array();
    $file_names = array();
    $date = 0;
    $i=0;
    $index=0;
    $dir = "./dh";
    $path = "C:/xampp/htdocs/xmlparser/dh";
    $fp = opendir($path);

    $handle = fopen("order_no.txt", "r");


    if (!file_exists("files_correct")) {

        mkdir("files_correct", 0777, true);
    }


    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            // process the line read.
            $move_file_names[$i] = $line;
            $i++;
        }

        fclose($handle);
    }


    $i=0;

    // Open a directory, and read its contents
    if (is_dir($dir)){

        if ($dh = opendir($dir)){

            while (($file = readdir($dh)) !== false){

                
                if($file_date = readdir($fp)){
                    
                        //putting logic to ignore hidden files
                    if($file==='.' || $file==='..' || $file_date==='.' || $file_date==='..' ){
                        continue;
                    }

                    //PUTTING LOGIC TO IGNORE RESPONSE FILES
                    if (strpos($file, 'response') !== false ||strpos($file_date, 'response') ){
                        continue;
                    }
                        //  getting the first part of file name and storing it in an array

                        $temp = explode("-",$file);
                        
                        if(!in_array($temp[0], $files))
                        {
                            $files[$i] = $temp[0];

                            $file_names[$i] = $file;

                            
                                $date =  date('d-m-Y H:i:s', filemtime($path . "/" . $file_date));

                                $date = explode(" ",$date);

                                $date = $date[0];

                                $file_create_dates[$i] = $date;

                                if(!in_array($date,  $Modified_file_dates))
                                {
                                    $Modified_file_dates[$index] = $date;
                                    mkdir("files_correct/".$date, 0777, true);
                                    $index++;
                                   
                                }
                                 $i++;
                        }
                }
            }
            
            
            $i=0;
        
            if (file_exists("files_correct")) {
                
                for($j=0; $j<sizeof($file_names); $j++)
                {
                    $temp = explode("-",$file_names[$j]);

                    if( intval($temp[0]) == intval($move_file_names[$i])) 
                    {
                        copy("dh/".$file_names[$j], "files_correct/".$file_create_dates[$j]."/".$file_names[$j]);
                       // rename("dh/".$file_names[$j] , "files_correct/".$file_names[$j]);
                        $i++;
                    }
                
                } 
            }

                   
        }
    }

                        
    
    closedir($fp);   
    closedir($dh);
    

?>
